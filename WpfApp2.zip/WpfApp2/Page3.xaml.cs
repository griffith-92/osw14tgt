﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Page3.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Page3 : Page
    {
        String f;
        Page2 p2 = new Page2();
        Page4 p4 = new Page4();
        Page5 p5 = new Page5();
        MainWindow win = new MainWindow();
        public Page3()
        {
            InitializeComponent();
        }

        private void bt_1_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FontDialog fontDialog = new System.Windows.Forms.FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                bt_1.FontFamily = new System.Windows.Media.FontFamily(fontDialog.Font.Name);
                double i = fontDialog.Font.Size;
                int d = (int)i;
                tb_1.Text = d.ToString();
                f = fontDialog.Font.Name;
                tb_2.FontWeight = fontDialog.Font.Bold ? FontWeights.Bold : FontWeights.Regular;
                tb_2.Text = f;
                //Page2
                p2.bt_1.FontFamily = bt_1.FontFamily;
                p2.bt_1.FontSize = fontDialog.Font.Size;
                p2.bt_2.FontFamily = bt_1.FontFamily;
                p2.bt_2.FontSize = fontDialog.Font.Size;
                p2.tb_1.FontFamily = bt_1.FontFamily;
                p2.tb_1.FontSize = fontDialog.Font.Size;
                p2.tb_2.FontFamily = bt_1.FontFamily;
                p2.tb_2.FontSize = fontDialog.Font.Size;
                p2.tb_3.FontFamily = bt_1.FontFamily;
                p2.tb_3.FontSize = fontDialog.Font.Size;
                p2.tb_4.FontFamily = bt_1.FontFamily;
                p2.tb_4.FontSize = fontDialog.Font.Size;
                p2.tb_5.FontFamily = bt_1.FontFamily;
                p2.tb_5.FontSize = fontDialog.Font.Size;
                p2.tb_6.FontFamily = bt_1.FontFamily;
                p2.tb_6.FontSize = fontDialog.Font.Size;

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ColorDialog dlg = new System.Windows.Forms.ColorDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                C_bt2.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(dlg.Color.A, dlg.Color.R, dlg.Color.G, dlg.Color.B));
            }
        }

        private void ReBT_Click(object sender, RoutedEventArgs e)
        {
            int resetSize = 12;
            System.Windows.Forms.FontDialog fontDialog = new System.Windows.Forms.FontDialog();
            C_bt1.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 0, 0, 0));
            tb_1.Text = "맑은 고딕";
            tb_2.FontFamily = new System.Windows.Media.FontFamily("맑은 고딕");
            tb_2.Text = ("맑은 고딕");
            p2.bt_1.FontFamily = tb_2.FontFamily;
            p2.bt_1.FontSize = resetSize;
            p2.bt_2.FontFamily = tb_2.FontFamily;
            p2.bt_2.FontSize = resetSize;
            p2.tb_1.FontFamily = tb_2.FontFamily;
            p2.tb_1.FontSize = resetSize;
            p2.tb_2.FontFamily = tb_2.FontFamily;
            p2.tb_2.FontSize = resetSize;
            p2.tb_3.FontFamily = tb_2.FontFamily;
            p2.tb_3.FontSize = resetSize;
            p2.tb_4.FontFamily = tb_2.FontFamily;
            p2.tb_4.FontSize = resetSize;
            p2.tb_5.FontFamily = tb_2.FontFamily;
            p2.tb_5.FontSize = resetSize;
            p2.tb_6.FontFamily = tb_2.FontFamily;
            p2.tb_6.FontSize = resetSize;
        }
    }
}
