﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();         
        }

        private void OCRBT_Click(object sender, RoutedEventArgs e)
        {
            frame_content.Source = new Uri("Page2.xaml", UriKind.Relative);
        }

        private void SubBT_Click(object sender, RoutedEventArgs e)
        {
            frame_content.Source = new Uri("Page5.xaml", UriKind.Relative);
        }

        private void SysBT_Click(object sender, RoutedEventArgs e)
        {
            frame_content.Source = new Uri("Page3.xaml", UriKind.Relative);
        }

        private void Main_Click(object sender, RoutedEventArgs e)
        {
            frame_content.Source = new Uri("Page4.xaml", UriKind.Relative);
        }
    }
}
