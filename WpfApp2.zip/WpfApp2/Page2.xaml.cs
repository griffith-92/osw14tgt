﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json.Linq;

namespace WpfApp2
{
    /// <summary>
    /// Page2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Page2 : Page
    {
        public Page2()
        {
            InitializeComponent();
        }

        public void Item_first()
        {
            Combo1.SelectedIndex = 0;
            Combo1.Items.Add("한글");

        }
        public void HTTPPost()
        {
            string sParam = "sParam1=value1&sParam2=value2";
            string sUrl = "http://abc/web";
            //서버 접속
            WebRequest webRequest = WebRequest.Create(sUrl);
            webRequest.Method = "POST";

            //데이터 전송
            byte[] bytearry = Encoding.UTF8.GetBytes(sParam);
            webRequest.ContentType = "application/x-www-form=urlencoded";
            webRequest.ContentLength = bytearry.Length;

            Stream stream = webRequest.GetRequestStream();
            stream.Write(bytearry, 0, bytearry.Length);
            stream.Close();

            //응답 데이터 받기
            WebResponse webResponse = webRequest.GetResponse();

            stream = webResponse.GetResponseStream();
            StreamReader streamReader = new StreamReader(stream);
            string sReturn = streamReader.ReadToEnd();

            streamReader.Close();
            stream.Close();
            webResponse.Close();

        }
        public void JsonParse()
        {
            using (WebClient wc = new WebClient())
            {
                wc.Encoding = Encoding.UTF8;
                string jsonURL = "URL"; //웹서버 주소
                string sParam = "파라미터"; //파라미터
                jsonURL = jsonURL + "/" + sParam;

                //웹서비스를 호출하고 리턴값을 가져옴
                string json = wc.DownloadString(jsonURL);

                //이 리턴값이 Json으로 되어있으면, 
                //NewtonSoft.Json을 설치하면 Newtonsoft.Json.Linq를 참조 후
                // JArray를 통한 리턴값을 파싱하고, JArray배열에 담는다.
                JArray array = JArray.Parse(json);

                //배열에서 원하는 데이터를 뽑는다.
                foreach (JObject jobj in array)
                {
                    string str = jobj["Key"].ToString();
                }
            }
        }
        private void Papago()
        {
            //요청 URL
            string sUrl = "https://openapi.naver.com/v1/papago/n2mt";
            //파라미터에 값넣기
            string sParam = string.Format("source={0}&target={1}&text={2}", Combo1.Text, Combo2.Text, textBox1.Text);

            //파라미터를 Chatacter Set에 맞게 변경
            byte[] bytearry = Encoding.UTF8.GetBytes(sParam);

            //서버에 요청
            WebRequest webRequest = WebRequest.Create(sUrl);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-urlencoded";

            //헤더 추가 
            webRequest.Headers.Add("X-Naver-Client-Id", "cccVZEaHlYP34hi1YABF");
            webRequest.Headers.Add("X-Naver-Client-Secret", "_oGk7K2bZL");

            //요청 데이터 길이
            webRequest.ContentLength = bytearry.Length;

            Stream stream = webRequest.GetRequestStream();
            stream.Write(bytearry, 0, bytearry.Length);
            stream.Close();

            // 응답 데이터 가져오기 (출력 포맷)
            HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
            stream = response.GetResponseStream();
            StreamReader streamReader = new StreamReader(stream);
            string sReturn = streamReader.ReadToEnd();

            streamReader.Close();
            stream.Close();
            response.Close();


            JObject jObject = JObject.Parse(sReturn);
            //JSON 출력포맷에서 필요한 번역된 부분만 가져오기
            textBox2.Text = jObject["message"]["result"]["translatedText"].ToString();
        }

        private void bt_1_Click(object sender, RoutedEventArgs e)
        {
            Papago();
        }
    }
}
