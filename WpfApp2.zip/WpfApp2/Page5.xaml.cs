﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Page5.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Page5 : Page
    {
        String reset = "10";
        String resetFont = "맑은 고딕";
        String j ;
        public Page5()
        {
            InitializeComponent();
        }


        private void bt_1_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FontDialog fontDialog = new System.Windows.Forms.FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {             
                tb_2.FontFamily = new System.Windows.Media.FontFamily(fontDialog.Font.Name);
                double i = fontDialog.Font.Size ;
                int d = (int)i;
                tb_1.Text = d.ToString();
                j = fontDialog.Font.Name;
                tb_2.FontWeight = fontDialog.Font.Bold ?  FontWeights.Bold : FontWeights.Regular;
                tb_2.Text = j;
               
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ColorDialog dlg = new System.Windows.Forms.ColorDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                C_bt1.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(dlg.Color.A, dlg.Color.R, dlg.Color.G, dlg.Color.B));
            }
        }

        private void C_bt2_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ColorDialog dlg = new System.Windows.Forms.ColorDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                C_bt2.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(dlg.Color.A,dlg.Color.R, dlg.Color.G, dlg.Color.B));
            }
        }

        private void resetBt_Click(object sender, RoutedEventArgs e)
        {
            C_bt1.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255,0,0,0));         
            C_bt2.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255,255,255,255));
        }

        private void ReBT_Click(object sender, RoutedEventArgs e)                                                   
        {
            System.Windows.Forms.FontDialog fontDialog = new System.Windows.Forms.FontDialog();
            C_bt1.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 0, 0, 0));
            C_bt2.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 255, 255, 255));
            tb_1.Text = reset;
            tb_2.FontFamily = new System.Windows.Media.FontFamily("맑은 고딕");
            tb_2.Text = ("맑은 고딕");
        }
    }
}
